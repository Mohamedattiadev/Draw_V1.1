"use client"

import type React from "react"

import { useEffect, useLayoutEffect, useRef, useState } from "react"
import { useAppContext } from "@/providers/AppStates"
import useDimension from "./useDimension"
import { lockUI } from "@/utils/ui"
import { draw, drawFocuse, cornerCursor, inSelectedCorner } from "@/utils/canvas"
import {
  adjustCoordinates,
  arrowMove,
  createElement,
  deleteElement,
  duplicateElement,
  getElementById,
  getElementPosition,
  minmax,
  resizeValue,
  saveElements,
  updateElement,
  uploadElements,
} from "@/utils/element"
import useKeys from "./useKeys"
import type { Corner, Element } from "@/types"

export default function useCanvas() {
  const {
    selectedTool,
    setSelectedTool,
    action,
    setAction,
    elements,
    setElements,
    scale,
    onZoom,
    translate,
    setTranslate,
    scaleOffset,
    setScaleOffset,
    lockTool,
    style,
    selectedElement,
    setSelectedElement,
    undo,
    redo,
  } = useAppContext()

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const keys = useKeys()
  const dimension = useDimension()
  const [isInElement, setIsInElement] = useState(false)
  const [inCorner, setInCorner] = useState<Corner | undefined>(undefined)
  const [padding, setPadding] = useState(minmax(10 / scale, [0.5, 50]))
  const [cursor, setCursor] = useState("default")
  const [mouseAction, setMouseAction] = useState({ x: 0, y: 0 })
  const [resizeOldDementions, setResizeOldDementions] = useState<Element | null>(null)

  const mousePosition = ({ clientX, clientY }: { clientX: number; clientY: number }) => {
    clientX = (clientX - translate.x * scale + scaleOffset.x) / scale
    clientY = (clientY - translate.y * scale + scaleOffset.y) / scale
    return { clientX, clientY }
  }

  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const { clientX, clientY } = mousePosition(event)
    lockUI(true)

    if (inCorner) {
      const element = getElementById(selectedElement?.id || "", elements)
      if (element) {
        setResizeOldDementions(element)
        setElements((prevState) => prevState)
        setMouseAction({ x: event.clientX, y: event.clientY })
        setCursor(cornerCursor(inCorner.slug))
        setAction("resize-" + inCorner.slug + (event.shiftKey ? "-shiftkey" : ""))
      }
      return
    }

    if (keys.has(" ") || selectedTool === "hand" || event.button === 1) {
      setTranslate((prevState) => ({
        ...prevState,
        sx: clientX,
        sy: clientY,
      }))
      setAction("translate")
      return
    }

    if (selectedTool === "selection") {
      const element = getElementPosition(clientX, clientY, elements)

      if (element) {
        const offsetX = clientX - element.x1
        const offsetY = clientY - element.y1

        if (event.altKey) {
          duplicateElement(element, setElements, setSelectedElement, 0, {
            offsetX,
            offsetY,
          })
        } else {
          setElements((prevState) => prevState)
          setMouseAction({ x: event.clientX, y: event.clientY })
          setSelectedElement({ ...element, offsetX, offsetY })
        }
        setAction("move")
      } else {
        setSelectedElement(null)
      }

      return
    }

    if (selectedTool !== "selection" && selectedTool !== "hand" && selectedTool !== "lock") {
      setAction("draw")
      const element = createElement(clientX, clientY, clientX, clientY, style, selectedTool)
      setElements((prevState) => [...prevState, element])
    }
  }

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const { clientX, clientY } = mousePosition(event)

    if (selectedElement) {
      const element = getElementById(selectedElement.id, elements)
      if (element) {
        setInCorner(inSelectedCorner(element, clientX, clientY, padding, scale))
      }
    }

    if (getElementPosition(clientX, clientY, elements)) {
      setIsInElement(true)
    } else {
      setIsInElement(false)
    }

    if (action === "draw") {
      const lastElement = elements.at(-1)
      if (lastElement) {
        updateElement(lastElement.id, { x2: clientX, y2: clientY }, setElements, elements, true)
      }
    } else if (action === "move") {
      if (!selectedElement) return
      const { id, x1, y1, x2, y2, offsetX, offsetY } = selectedElement

      const width = x2 - x1
      const height = y2 - y1

      const nx = clientX - (offsetX || 0)
      const ny = clientY - (offsetY || 0)

      updateElement(id, { x1: nx, y1: ny, x2: nx + width, y2: ny + height }, setElements, elements, true)
    } else if (action === "translate") {
      const x = clientX - translate.sx
      const y = clientY - translate.sy

      setTranslate((prevState) => ({
        ...prevState,
        x: prevState.x + x,
        y: prevState.y + y,
      }))
    } else if (action.startsWith("resize")) {
      if (!selectedElement || !resizeOldDementions) return
      const resizeCorner = action.slice(7, 9)
      const resizeType = action.slice(10) || "default"
      const s_element = getElementById(selectedElement.id, elements)
      if (!s_element) return

      updateElement(
        s_element.id,
        resizeValue(resizeCorner, resizeType, clientX, clientY, padding, s_element, mouseAction, resizeOldDementions),
        setElements,
        elements,
        true,
      )
    }
  }

  const handleMouseUp = (event: React.MouseEvent<HTMLCanvasElement>) => {
    setAction("none")
    lockUI(false)

    if (event.clientX === mouseAction.x && event.clientY === mouseAction.y) {
      setElements("prevState")
      return
    }

    if (action === "draw") {
      const lastElement = elements.at(-1)
      if (lastElement) {
        const { id, x1, y1, x2, y2 } = adjustCoordinates(lastElement)
        updateElement(id, { x1, x2, y1, y2 }, setElements, elements, true)
        if (!lockTool) {
          setSelectedTool("selection")
          setSelectedElement(lastElement)
        }
      }
    }

    if (action.startsWith("resize") && selectedElement) {
      const element = getElementById(selectedElement.id, elements)
      if (element) {
        const { id, x1, y1, x2, y2 } = adjustCoordinates(element)
        updateElement(id, { x1, x2, y1, y2 }, setElements, elements, true)
      }
    }
  }

  const handleWheel = (event: React.WheelEvent<HTMLCanvasElement>) => {
    if (event.ctrlKey) {
      onZoom(event.deltaY * -0.01)
      return
    }

    setTranslate((prevState) => ({
      ...prevState,
      x: prevState.x - event.deltaX,
      y: prevState.y - event.deltaY,
    }))
  }

  useLayoutEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const context = canvas.getContext("2d")
    if (!context) return

    const zoomPositionX = 2
    const zoomPositionY = 2

    const scaledWidth = canvas.width * scale
    const scaledHeight = canvas.height * scale

    const scaleOffsetX = (scaledWidth - canvas.width) / zoomPositionX
    const scaleOffsetY = (scaledHeight - canvas.height) / zoomPositionY

    setScaleOffset({ x: scaleOffsetX, y: scaleOffsetY })

    context.clearRect(0, 0, canvas.width, canvas.height)

    context.save()

    context.translate(translate.x * scale - scaleOffsetX, translate.y * scale - scaleOffsetY)
    context.scale(scale, scale)

    let focusedElement: Element | undefined
    elements.forEach((element) => {
      draw(element, context)
      if (element.id === selectedElement?.id) focusedElement = element
    })

    const pd = minmax(10 / scale, [0.5, 50])
    if (focusedElement) {
      drawFocuse(focusedElement, context, pd, scale)
    }
    setPadding(pd)

    context.restore()
  }, [elements, selectedElement, scale, translate, dimension])

  useEffect(() => {
    const keyDownFunction = (event: KeyboardEvent) => {
      const { key, ctrlKey, metaKey, shiftKey } = event
      const prevent = () => event.preventDefault()
      if (selectedElement) {
        if (key === "Backspace" || key === "Delete") {
          prevent()
          deleteElement(selectedElement, setElements, setSelectedElement)
        }

        if (ctrlKey && key.toLowerCase() === "d") {
          prevent()
          duplicateElement(selectedElement, setElements, setSelectedElement, 10)
        }

        if (key === "ArrowLeft") {
          prevent()
          arrowMove(selectedElement, -1, 0, setElements)
        }
        if (key === "ArrowUp") {
          prevent()
          arrowMove(selectedElement, 0, -1, setElements)
        }
        if (key === "ArrowRight") {
          prevent()
          arrowMove(selectedElement, 1, 0, setElements)
        }
        if (key === "ArrowDown") {
          prevent()
          arrowMove(selectedElement, 0, 1, setElements)
        }
      }

      if (ctrlKey || metaKey) {
        if (key.toLowerCase() === "y" || (key.toLowerCase() === "z" && shiftKey)) {
          prevent()
          redo()
        } else if (key.toLowerCase() === "z") {
          prevent()
          undo()
        } else if (key.toLowerCase() === "s") {
          prevent()
          saveElements(elements)
        } else if (key.toLowerCase() === "o") {
          prevent()
          uploadElements(setElements)
        }
      }
    }

    window.addEventListener("keydown", keyDownFunction, { passive: false })
    return () => {
      window.removeEventListener("keydown", keyDownFunction)
    }
  }, [undo, redo, selectedElement, elements, setElements, setSelectedElement])

  useEffect(() => {
    if (selectedTool !== "selection") {
      setSelectedElement(null)
    }
  }, [selectedTool, setSelectedElement])

  useEffect(() => {
    if (typeof document === "undefined") return

    if (action === "translate") {
      document.documentElement.style.setProperty("--canvas-cursor", "grabbing")
    } else if (action.startsWith("resize")) {
      document.documentElement.style.setProperty("--canvas-cursor", cursor)
    } else if ((keys.has(" ") || selectedTool === "hand") && action !== "move" && !action.startsWith("resize")) {
      document.documentElement.style.setProperty("--canvas-cursor", "grab")
    } else if (selectedTool !== "selection") {
      document.documentElement.style.setProperty("--canvas-cursor", "crosshair")
    } else if (inCorner) {
      document.documentElement.style.setProperty("--canvas-cursor", cornerCursor(inCorner.slug))
    } else if (isInElement) {
      document.documentElement.style.setProperty("--canvas-cursor", "move")
    } else {
      document.documentElement.style.setProperty("--canvas-cursor", "default")
    }
  }, [keys, selectedTool, action, isInElement, inCorner, cursor])

  useEffect(() => {
    const fakeWheel = (event: WheelEvent) => {
      if (event.ctrlKey) {
        event.preventDefault()
      }
    }
    window.addEventListener("wheel", fakeWheel, {
      passive: false,
    })

    return () => {
      window.removeEventListener("wheel", fakeWheel)
    }
  }, [])

  return {
    canvasRef,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleWheel,
    dimension,
  }
}
